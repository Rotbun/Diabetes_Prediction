import tkinter as tk
from tkinter import ttk
from tkinter import messagebox
import pandas as pd
import numpy as np
import joblib  # Use joblib if that's how you saved your scaler
from PIL import Image, ImageTk

# Load the saved diabetes prediction model
with open('best_model.pkl', 'rb') as file:
    model = pickle.load(file)

# Load the scaler object
scaler = joblib.load('scaler1.pkl')  # Use joblib to load the scaler if saved with joblib

# Create the main application window
app = tk.Tk()
app.title("Diabetes Prediction App")

# Set window dimensions
app.geometry("800x600")  # Increase window size for better layout

# Color scheme
bg_color = "#f0f8ff"  # Mild blue background color
fg_color = "#000000"  # Black text color
btn_color = "#4682b4"  # Darker blue for buttons
entry_bg = "#ffffff"   # White background for entries

# Set background color for the app window
app.configure(bg=bg_color)

# Add a background image to the main window (optional)
try:
    background_image = Image.open("background.jpg")  # Replace with your image path
    background_image = background_image.resize((1000, 800), Image.LANCZOS)
    background_photo = ImageTk.PhotoImage(background_image)
    background_label = tk.Label(app, image=background_photo)
    background_label.place(relwidth=1, relheight=1)
except Exception as e:
    print(f"Background image error: {e}")

# Create a frame for the app's content with a transparent background
content_frame = tk.Frame(app, bg=bg_color)
content_frame.place(relwidth=0.8, relheight=0.8, relx=0.1, rely=0.1)

# Define a custom font for the title
title_font = ("Helvetica", 16, "bold")
label_font = ("Helvetica", 12, "bold")

# Create a title label and centralize it
title_label = tk.Label(app, text="Diabetes Predictor", font=title_font, bg=bg_color, fg=fg_color)
title_label.pack(pady=20)  # Centralize using pack

# Define variables
gender_var = tk.StringVar()
age_var = tk.StringVar()
hypertension_var = tk.StringVar()
heart_disease_var = tk.StringVar()
smoking_history_var = tk.StringVar()
bmi_var = tk.StringVar()
HbA1c_level_var = tk.StringVar()
blood_glucose_level_var = tk.StringVar()

# Function to preprocess user input and make predictions
def predict_diabetes():
    try:
        # Get user input from the entry widgets
        gender = gender_var.get()
        age = float(age_var.get())
        hypertension = 1 if hypertension_var.get() == "Yes" else 0
        heart_disease = 1 if heart_disease_var.get() == "Yes" else 0
        smoking_history = smoking_history_var.get()
        bmi = float(bmi_var.get())
        HbA1c_level = float(HbA1c_level_var.get())
        blood_glucose_level = float(blood_glucose_level_var.get())

        # Encode categorical variables
        smoking_encoded = {'never': 0, 'current': 1, 'No Info': 2}.get(smoking_history, 0)
        gender_encoded = 1 if gender == "Male" else 0

        # Create a DataFrame for preprocessing
        input_data = pd.DataFrame({
            'gender': [gender_encoded],
            'age': [age],
            'hypertension': [hypertension],
            'heart_disease': [heart_disease],
            'smoking_history': [smoking_encoded],
            'bmi': [bmi],
            'HbA1c_level': [HbA1c_level],
            'blood_glucose_level': [blood_glucose_level]
        })

        # Ensure the input data is in the correct format
        input_data = pd.DataFrame(input_data, columns=['gender', 'age', 'hypertension', 'heart_disease', 'smoking_history', 'bmi', 'HbA1c_level', 'blood_glucose_level'])

        # Standardize the input data
        standardized_data = scaler.transform(input_data)

        # Make a prediction using the loaded model
        prediction = model.predict(standardized_data)

        # Display the predicted result to the user
        prediction_text = "The Patient is Likely Diabetic" if prediction[0] == 1 else "The Patient is Likely not Diabetic"
        messagebox.showinfo("Prediction Result", f"The predicted result is: {prediction_text}")
    except ValueError as e:
        messagebox.showerror("Error", str(e))

# Create and configure input widgets
tk.Label(content_frame, text="Gender (Male/Female):", font=label_font, bg=bg_color, fg=fg_color).grid(row=1, column=0, sticky="E", padx=10, pady=5)
ttk.Entry(content_frame, textvariable=gender_var).grid(row=1, column=1, padx=10, pady=5)

tk.Label(content_frame, text="Age:", font=label_font, bg=bg_color, fg=fg_color).grid(row=2, column=0, sticky="E", padx=10, pady=5)
ttk.Entry(content_frame, textvariable=age_var).grid(row=2, column=1, padx=10, pady=5)

tk.Label(content_frame, text="Hypertension (Yes/No):", font=label_font, bg=bg_color, fg=fg_color).grid(row=3, column=0, sticky="E", padx=10, pady=5)
ttk.Entry(content_frame, textvariable=hypertension_var).grid(row=3, column=1, padx=10, pady=5)

tk.Label(content_frame, text="Heart Disease (Yes/No):", font=label_font, bg=bg_color, fg=fg_color).grid(row=4, column=0, sticky="E", padx=10, pady=5)
ttk.Entry(content_frame, textvariable=heart_disease_var).grid(row=4, column=1, padx=10, pady=5)

tk.Label(content_frame, text="Smoking History (never/current/No Info):", font=label_font, bg=bg_color, fg=fg_color).grid(row=5, column=0, sticky="E", padx=10, pady=5)
ttk.Entry(content_frame, textvariable=smoking_history_var).grid(row=5, column=1, padx=10, pady=5)

tk.Label(content_frame, text="BMI:", font=label_font, bg=bg_color, fg=fg_color).grid(row=6, column=0, sticky="E", padx=10, pady=5)
ttk.Entry(content_frame, textvariable=bmi_var).grid(row=6, column=1, padx=10, pady=5)

tk.Label(content_frame, text="HbA1c Level:", font=label_font, bg=bg_color, fg=fg_color).grid(row=7, column=0, sticky="E", padx=10, pady=5)
ttk.Entry(content_frame, textvariable=HbA1c_level_var).grid(row=7, column=1, padx=10, pady=5)

tk.Label(content_frame, text="Blood Glucose Level:", font=label_font, bg=bg_color, fg=fg_color).grid(row=8, column=0, sticky="E", padx=10, pady=5)
ttk.Entry(content_frame, textvariable=blood_glucose_level_var).grid(row=8, column=1, padx=10, pady=5)

style = ttk.Style()
style.configure("TButton", font=("Helvetica", 12, "bold"))
style.map("TButton",
          foreground=[("active", "#00008B"), ("!active", "#00008B")])  # Dark blue text color

# Create a button to make predictions with the new style
predict_button = ttk.Button(content_frame, text="Predict", command=predict_diabetes, style="TButton")
predict_button.grid(row=9, column=1, columnspan=3, padx=5, pady=10)


# Start the Tkinter main loop
app.mainloop()
